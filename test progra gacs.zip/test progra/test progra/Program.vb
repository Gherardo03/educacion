Imports System

Module Program



    Sub Main()
            Dim paises(4) As String
            Dim gentilicios(4) As String
            Dim tiposAnimales(4) As String
            Dim especiesAnimales(4) As String

        ' Capturar datos de 5 humanos
        'aqui se ingresara los datos para la informacion del pais y su gentilicio, 
        'se guardan los datos en las variables en los rangos de 1 al 5
        For i As Integer = 0 To 4
                Console.WriteLine("Ingrese el pa�s para el humano " & (i + 1) & ": ")
                paises(i) = Console.ReadLine()
                Console.WriteLine("Ingrese el gentilicio para el pa�s " & paises(i) & ": ")
                gentilicios(i) = Console.ReadLine()
            Next

            ' Capturar datos de 5 animales
            For i As Integer = 0 To 4
                Console.WriteLine("Ingrese el tipo de animal " & (i + 1) & ": ")
                tiposAnimales(i) = Console.ReadLine()
                Console.WriteLine("Ingrese la especie del animal " & tiposAnimales(i) & ": ")
                especiesAnimales(i) = Console.ReadLine()
            Next

        ' Mostrar el men� de opciones con los datos ya guardados en las varibles de texto
        Console.WriteLine("Seleccione una opci�n:")
            Console.WriteLine("1. Humanos")
            Console.WriteLine("2. Animales")

            Dim opcion As Integer = Integer.Parse(Console.ReadLine())

            If opcion = 1 Then
                ' Opci�n seleccionada: Humanos
                Console.WriteLine("Ingrese el pa�s para el cual desea conocer el gentilicio: ")
                Dim paisBuscado As String = Console.ReadLine()
                Dim encontrado As Boolean = False



            'mediante el metodo for se hace llamado al menu del 1 al 5 donde se tiene guardado los datos de pais y su gentilicio y animal con 
            'especie usando tipo de texto string. si al selecionar la opcion correcta se mostrara el texto que tiene guardado en la variables.
            For i As Integer = 0 To 4
                    If paises(i).Equals(paisBuscado, StringComparison.OrdinalIgnoreCase) Then
                        Console.WriteLine("El gentilicio para " & paisBuscado & " es " & gentilicios(i))
                        encontrado = True
                        Exit For
                    End If
                Next

                If Not encontrado Then
                    Console.WriteLine("Pa�s no encontrado.")
                End If
            ElseIf opcion = 2 Then
                ' Opci�n seleccionada: Animales
                Console.WriteLine("Ingrese el tipo de animal para el cual desea conocer la especie: ")
                Dim tipoAnimalBuscado As String = Console.ReadLine()
                Dim encontrado As Boolean = False

                For i As Integer = 0 To 4
                    If tiposAnimales(i).Equals(tipoAnimalBuscado, StringComparison.OrdinalIgnoreCase) Then
                        Console.WriteLine("La especie para el tipo de animal " & tipoAnimalBuscado & " es " & especiesAnimales(i))
                        encontrado = True
                        Exit For
                    End If
                Next

                If Not encontrado Then
                    Console.WriteLine("Tipo de animal no encontrado.")
                End If
            Else
                Console.WriteLine("Opci�n no v�lida.")
            End If

        Console.ReadLine()
        'hecho por gerardo alexander cabrera sandoval

    End Sub
    End Module

